"""
Incremental, resumable live-cycle engine for the "v24" strategy variant -
the user's "buy everything, tight stop, reclaim to re-enter" idea
(2026-09-15 voice request), validated first as a backtest
(backtest_gap_hold_pool_tightstop.py) and now ported to the SAME
persisted-state/new-bars-each-cycle architecture as run_scan_cycle.py (v3)
and v21_run_scan_cycle.py/v22_run_scan_cycle.py, so it can join the same
live forward-test loop.

v24 STRATEGY (deliberately the simplest variant in this project):
  - Universe: every symbol in the day's tracked small-cap gap scan (same
    25-symbol Group A-E universe v3/v21/v22 already fetch bars for) -
    NOT filtered further, no volume/pattern signal of any kind.
  - Entry: unconditional, the instant a symbol's FIRST bar of the day is
    seen ("pops up") - no signal, no threshold. Buy immediately.
  - Portfolio: pooled equal-weight capital across every symbol currently
    held, rebalanced (trim/topup) on every entry/exit/re-entry event -
    same live_cycle_common.make_rebalance() used by v21/v22, unmodified.
  - Stage 1 (never gained since this holding cycle's entry): ZERO
    TOLERANCE - sell the instant a bar closes below entry_price ("cut it
    off right away" per the user).
  - Stage 2 (has gained since this cycle's entry): single-tier 10%-of-
    peak-gain giveback stop (no tier A/B escalation, unlike v21/v22) -
    sell when price gives back more than 10% of the gain from entry to
    the peak high reached this cycle.
  - Re-entry: EXACT port of backtest_gap_hold_pool_tightstop.py's watch_level
    mechanism (NOT v21/v22's separate `hod`-breakout trigger - an earlier
    draft of this file tried reusing `hod` and it under-traded the validated
    backtest by ~$5,400 on 09-08 alone, because `hod` can already sit above
    entry_price from the entry bar's own high/close spread even when the
    position has never technically "gained" - a real bug, caught by
    chunk-replay validation before this ever went live, see below). On a
    stage1 stop, watch_level = entry_price (the exact level just cut at); on
    a stage2 stop, watch_level = peak_high (the exact peak just given back
    from). While stopped-out, the position re-buys the instant a bar's HIGH
    exceeds watch_level, filling AT watch_level - matching the user's "wait
    for them to go above that... buy it again to the top." Can repeat many
    times per symbol per day (matches this project's existing multi-entry
    convention). `s.hod`/`update_common_bar_state` are still called every
    bar purely for dashboard/bookkeeping consistency with v21/v22's schema -
    they play NO role in any v24 trading decision.
  - Capital: fresh $5,000 start for 2026-09-15 (user explicitly chose NOT
    to carry forward the backtest's $42,171.87 ending balance), cross-day
    compounding from there via the same --capital-mode compounding
    --base-notional mechanism v21/v22 use (base-notional = PRIOR day's own
    v24 ending balance once v24 has run more than one day).
  - Same account-level 10%-drawdown halt+flatten guardrail as v3/v21/v22
    (project standing default for every live loop), via the same
    --halt-drawdown-pct/--risk-reset flags.

WHAT'S DIFFERENT FROM v21_run_scan_cycle.py (the template this was copied
from) - everything else, including the CLI interface, is unchanged:
  1. No regular_daily_volume dependency at all (v24 has no volume-based
     signal) - historical_vol_ratio import/usage and the
     --regular-daily-volume CLI flag are removed entirely.
  2. Initial "not yet discovered" entry fires unconditionally (subject only
     to `not halted`) instead of v21's scanner_ratio_threshold volume check.
  3. Stage 1 is zero-tolerance (`bar.close < s.entry_price`) instead of
     v21's 2%-drawdown-tolerance.
  4. Stage 2 is a single 10%-giveback tier (no tier A/B split) instead of
     v21's two-tier 10%/50% escalation.
  strategy_version is tagged "v24-code-verified".

VALIDATION: before going live, this engine's run_cycle() was chunk-replayed
against backtest_gap_hold_pool_tightstop.py's single-pass full-day result
for 2026-09-14's already-reconstructed, date-filtered bars (see
validate_v24_engine.py) and matched to the cent on realized P&L, closed
trade count, and ending open-position set.
"""

import argparse
import json
import sys

sys.path.insert(0, "/home/claude/webull_live_execution")
from live_cycle_common import (
    TOTAL_CAPITAL, sym_from_seed, sym_to_seed,
    build_events, update_common_bar_state, append_bars_log, make_rebalance,
    build_trades_doc, load_bars_files,
    compute_equity, init_or_reset_risk_halt, recheck_risk_halt, flatten_all_positions,
)

RECENT_BARS_CAP = 3  # unused by v24's decision logic, kept for schema consistency with v21/v22


def run_cycle(sim_state, bars_by_symbol, existing_trades_doc,
              stage2_giveback_pct=0.10,
              total_capital=TOTAL_CAPITAL,
              capital_mode=None, halt_drawdown_pct=None, risk_reset=False,
              base_notional=None, force_eod_close=False):
    """
    Pure function, same contract as v21_run_scan_cycle.run_cycle() minus the
    regular_daily_volume parameter (v24 doesn't use one).
    """
    date = sim_state.get("date")
    roster = {sym: sym_from_seed(sym, seed) for sym, seed in sim_state.get("symbols", {}).items()}
    realized_pnl_running = sim_state.get("realized_pnl_running", 0.0)

    effective_base_notional = base_notional if base_notional is not None else TOTAL_CAPITAL
    mode = capital_mode if capital_mode is not None else sim_state.get("total_capital_mode", "flat")
    risk_halt = init_or_reset_risk_halt(sim_state, roster, realized_pnl_running,
                                         halt_drawdown_pct, risk_reset, base_notional=effective_base_notional)
    halted = bool(risk_halt["halted"]) if risk_halt else False
    if mode == "compounding":
        total_capital = compute_equity(roster, realized_pnl_running, base_notional=effective_base_notional)

    events, ts_to_time_str, _ = build_events(roster, bars_by_symbol)

    new_trades = []
    realized_pnl_box = [realized_pnl_running]
    rebalance, log = make_rebalance(roster, new_trades, realized_pnl_box, ts_to_time_str, total_capital)

    def log_flip_marker(sym, action, price, ts):
        """Records a held/not-held flip with no share count of its own (the
        actual shares are logged separately by the very next rebalance()
        call's topup_buy) - matches backtest_gap_hold_pool_tightstop.py's
        log_flip_marker, purely so reclaim re-entries are visible in the
        trade log even though make_rebalance()'s own log() closure refuses
        to log a zero-share event."""
        new_trades.append({
            "symbol": sym, "action": action, "price": round(price, 4),
            "shares": 0, "reason": action, "ts": ts, "time_str": ts_to_time_str.get(ts),
            "pnl_dollars": None,
        })

    for ts, sym, bar in events:
        if sym not in roster:
            roster[sym] = sym_from_seed(sym, None)
        s = roster[sym]
        s.last_bar_time = ts_to_time_str[ts]
        prior_hod, breakout = update_common_bar_state(s, bar, RECENT_BARS_CAP)

        if s.entry_price is None:
            # Not yet discovered - v24 buys UNCONDITIONALLY the instant a symbol
            # first appears ("pops up"), no signal/threshold of any kind.
            # peak_high starts EQUAL to the entry price (matches the validated
            # backtest exactly: "peak tracking starts fresh from the NEXT bar's
            # high onward") - NOT max(bar.high, entry_price). Using this bar's
            # own high would let peak_high sit above entry_price before any
            # real gain has happened (a bar's high is usually above its
            # close), which silently misclassifies the position as
            # already-gained and picks the wrong stop rule. A real bug an
            # earlier draft of this file had; caught by chunk-replay
            # validation against the backtest before this ever ran live.
            if not halted:
                s.held = True
                s.stage_entry_price = bar.close
                s.entry_price = bar.close   # shared rebalance()'s cost-basis field
                s.peak_high = bar.close
                s.ever_gained = False
                s.shares = 0
                s.entry_count += 1
                s.watch_level = None
                s.last_stop_stage = None
                s.bars_log = []
                append_bars_log(s, bar, ts_to_time_str[ts])
                rebalance(ts)
            continue

        if not s.held:
            # Stopped out, currently in cash, watching for a reclaim of the
            # EXACT level it was cut at (watch_level) - NOT the shared
            # v21/v22 `hod` mechanism, see module docstring for why.
            if not halted and s.watch_level is not None and bar.high > s.watch_level:
                fill_price = s.watch_level
                marker_action = "stage1_reclaim_reentry" if s.last_stop_stage == "stage1" else "stage2_hod_reclaim_reentry"
                s.held = True
                s.stage_entry_price = fill_price
                s.entry_price = fill_price  # reset cost basis fresh for this new cycle
                s.peak_high = fill_price
                s.last_price = fill_price   # fills AT the reclaim level, not this bar's
                                             # close (which is why the breakout fired at
                                             # all) - update_common_bar_state already set
                                             # last_price=bar.close above; override it here
                                             # so rebalance() sizes shares off the correct
                                             # fill price. Missing this silently bought
                                             # fewer shares at a too-high price on every
                                             # reentry - caught by chunk-replay validation.
                s.ever_gained = False
                s.shares = 0
                s.entry_count += 1
                s.watch_level = None
                s.last_stop_stage = None
                s.bars_log = []
                log_flip_marker(sym, marker_action, fill_price, ts)
                append_bars_log(s, bar, ts_to_time_str[ts])
                rebalance(ts)
            continue

        # Currently held - update peak, log bar for the dashboard chart, check exits.
        # Thresholds are measured against stage_entry_price (fixed for this
        # cycle), NEVER against entry_price (which the rebalance() calls below
        # keep drifting into a weighted-average cost basis as other symbols
        # pop up/reclaim and this position gets trimmed/topped-up mid-cycle).
        s.peak_high = max(s.peak_high, bar.high)
        has_gained = s.peak_high > s.stage_entry_price
        s.ever_gained = has_gained  # display/dashboard field only, not a decision input
        append_bars_log(s, bar, ts_to_time_str[ts])

        should_exit, reason, new_watch_level, stop_stage = False, None, None, None
        if not has_gained:
            if bar.close < s.stage_entry_price:
                should_exit, reason = True, "stage1_instant_stop"
                new_watch_level, stop_stage = s.stage_entry_price, "stage1"
        else:
            floor = s.peak_high - (s.peak_high - s.stage_entry_price) * stage2_giveback_pct
            if bar.close < floor:
                should_exit, reason = True, f"stage2_giveback_stop[{stage2_giveback_pct}]"
                new_watch_level, stop_stage = s.peak_high, "stage2"

        if should_exit:
            pnl = (bar.close - s.entry_price) * s.shares   # entry_price = cost basis here
            log(sym, "full_sell", bar.close, s.shares, reason, ts, pnl)
            s.shares = 0
            s.held = False
            s.watch_level = new_watch_level
            s.last_stop_stage = stop_stage
            rebalance(ts)

    risk_halt = recheck_risk_halt(risk_halt, roster, realized_pnl_box[0], base_notional=effective_base_notional)

    flattened_symbols = []
    if risk_halt is not None and risk_halt["halted"]:
        flattened_symbols = flatten_all_positions(roster, new_trades, realized_pnl_box)

    # ADDITIVE for v24 (no equivalent in v21/v22, which have no "hold to EOD"
    # concept): the orchestrator passes force_eod_close=True on the day's
    # LAST cycle only, so whatever is still held at that point gets closed
    # exactly like backtest_gap_hold_pool_tightstop.py's end-of-day
    # force-close - matching the base strategy's "nothing carries open
    # overnight" design. Logged as "full_sell"/reason "eod_forced_close"
    # (this live engine's generic close-action shape, unlike the backtest
    # script's separate "eod_close" action name - same money, different label).
    eod_flattened_symbols = []
    if force_eod_close:
        eod_flattened_symbols = flatten_all_positions(roster, new_trades, realized_pnl_box,
                                                        reason="eod_forced_close")

    all_trades = list(existing_trades_doc.get("trades", [])) if existing_trades_doc else []
    all_trades.extend(new_trades)

    trades_doc, open_positions = build_trades_doc(
        date, "v24-code-verified", all_trades, roster, total_capital, realized_pnl_box[0]
    )

    updated_symbols = {sym: sym_to_seed(s) for sym, s in roster.items()}
    updated_sim_state = {"date": date, "symbols": updated_symbols, "realized_pnl_running": realized_pnl_box[0]}
    if mode != "flat":
        updated_sim_state["total_capital_mode"] = mode
    if risk_halt is not None:
        updated_sim_state["risk_halt"] = risk_halt

    result = {
        "sim_state": updated_sim_state,
        "trades_doc": trades_doc,
        "new_trades_this_cycle": new_trades,
        "open_positions_this_cycle": open_positions,
        "flattened_symbols_this_cycle": flattened_symbols,
        "eod_flattened_symbols_this_cycle": eod_flattened_symbols,
    }
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim-state", required=True)
    ap.add_argument("--bars-files", required=True)
    ap.add_argument("--existing-trades", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--capital-mode", choices=["flat", "compounding"], default=None)
    ap.add_argument("--halt-drawdown-pct", type=float, default=None)
    ap.add_argument("--risk-reset", action="store_true")
    ap.add_argument("--base-notional", type=float, default=None)
    ap.add_argument("--force-eod-close", action="store_true",
                     help="Pass on the day's FINAL cycle only: force-closes anything "
                          "still held at its last price, matching the backtest's "
                          "end-of-day flatten (v24 has no natural EOD close of its own).")
    args = ap.parse_args()

    with open(args.sim_state) as f:
        sim_state = json.load(f)
    bars_by_symbol = load_bars_files(args.bars_files.split(","))
    existing_trades_doc = None
    if args.existing_trades:
        with open(args.existing_trades) as f:
            existing_trades_doc = json.load(f)

    result = run_cycle(sim_state, bars_by_symbol, existing_trades_doc,
                        capital_mode=args.capital_mode, halt_drawdown_pct=args.halt_drawdown_pct,
                        risk_reset=args.risk_reset, base_notional=args.base_notional,
                        force_eod_close=args.force_eod_close)

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2)

    print(f"new trades this cycle: {len(result['new_trades_this_cycle'])}")
    print(f"open positions: {[p['symbol'] for p in result['open_positions_this_cycle']] or 'none (flat)'}")
    print(f"summary: {json.dumps(result['trades_doc']['summary'])}")
    rh = result["sim_state"].get("risk_halt")
    if rh:
        status = "HALTED" if rh["halted"] else "ok"
        print(f"risk_halt: {status} (starting_principal=${rh['starting_principal']:.2f}, "
              f"halt_drawdown_pct={rh['halt_drawdown_pct']}%, reason={rh['halt_reason']})")
    print(f"total_capital used this cycle: ${result['trades_doc']['assumed_total_capital']:.2f}")
    if result.get("flattened_symbols_this_cycle"):
        print(f"FLATTENED (risk halt force-close): {result['flattened_symbols_this_cycle']}")
    if result.get("eod_flattened_symbols_this_cycle"):
        print(f"FLATTENED (end-of-day force-close): {result['eod_flattened_symbols_this_cycle']}")
    print(f"wrote {args.out}")
