"""
Shared plumbing for the v21 and v22 LIVE forward-test cycle engines
(v21_run_scan_cycle.py / v22_run_scan_cycle.py).

WHY THIS FILE EXISTS: v21 and v22 (see backtest_v21.py / backtest_v22.py in
the analysis scratchpad) share byte-identical bar-loading, rebalance, and
trade-logging mechanics - only the entry/exit DECISION logic differs between
them (see each engine file's own module docstring). Factoring the identical
parts out here means a bug fix or refinement to the shared mechanics (e.g.
the rebalance math) only has to happen once and automatically applies to
both live engines, instead of drifting between two copy-pasted files. This
is a new file, not a modification of anything that already existed.

DESIGN NOTE ON WHY THIS DOES NOT IMPORT THE BACKTEST SCRIPTS: backtest_v21.py
/ backtest_v22.py do `import backtest_v10` to reuse
`backtest_v10.historical_vol_ratio` and read the module-level
`backtest_v10.REGULAR_DAILY_VOLUME` dict - that only resolves because those
scripts are run with their own directory (the analysis scratchpad) on
sys.path. A live production engine living in webull_live_execution/ should
not depend on files that live in a temporary analysis scratchpad, so:
  - `historical_vol_ratio` is reproduced here verbatim (it is a tiny, pure,
    6-line function - see the docstring on the copy below for exactly where
    it was verified from and confirmation of what it does/doesn't need).
  - the REGULAR_DAILY_VOLUME baseline is passed in explicitly as a regular
    parameter (loaded from a JSON file via --regular-daily-volume), not
    read off a monkeypatched module global. See compute_regular_daily_volume.py
    for how that baseline should be produced for a live trading day.

STATE MODEL (mirrors backtest_v21.py/backtest_v22.py's `Sym` class exactly,
pluralized/persisted instead of living only in an in-memory dict for one
run): each symbol tracks held/shares/entry_price/peak_high/last_price/
ever_gained/hod/entry_count exactly as the backtests do. `recent_bars` (last
few bars' open/close) and `bars_log` (a longer, capped OHLC history for a
dashboard chart) are additional bookkeeping the backtests don't need (they
have the whole day's bar array in memory at once) but a resumable live cycle
does:
  - `recent_bars` is what makes v22's revival re-entry trigger ("N
    consecutive green bars ending at this bar") evaluable correctly across a
    cycle boundary - it is unused by v21 but present on every symbol's state
    for schema consistency between the two engines.
  - `bars_log` is purely for the live dashboard's price chart on an open
    position; it never affects any trading decision.
"""

import json
from collections import namedtuple
from datetime import datetime, timezone

Bar = namedtuple("Bar", ["ts", "open", "high", "low", "close", "volume"])

TOTAL_CAPITAL = 5000.0
SESSION_MINUTES = 960  # 4am-8pm ET extended session, same constant backtest_v10.py uses
MAX_BARS_LOG = 60      # cap on the dashboard chart history per open position, mirrors
                        # run_scan_cycle.py's MAX_BARS_ON_OPEN_POSITION


def parse_ts(s):
    return int(datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%f%z").timestamp())


def load_bars_files(paths):
    """
    Parse one or more raw mcp__Webull__get_stock_bars-shaped JSON files
    ({"result": [{"symbol":..., "result":[bars...]}, ...]}) into
    {symbol: [bar_meta, ...]} sorted ascending by ts. bar_meta carries both
    the parsed numeric OHLCV and the original time string (for logging/
    dashboard display), same shape run_scan_cycle.py's load_bars_files uses.
    """
    all_symbol_bars = {}
    for path in paths:
        with open(path) as f:
            doc = json.load(f)
        for entry in doc["result"]:
            sym = entry["symbol"]
            bars_meta = []
            for rb in entry["result"]:
                bars_meta.append({
                    "ts": parse_ts(rb["time"]), "time_str": rb["time"],
                    "open": float(rb["open"]), "high": float(rb["high"]), "low": float(rb["low"]),
                    "close": float(rb["close"]), "volume": float(rb["volume"]),
                })
            bars_meta.sort(key=lambda b: b["ts"])
            all_symbol_bars.setdefault(sym, []).extend(bars_meta)
    for sym in all_symbol_bars:
        all_symbol_bars[sym].sort(key=lambda b: b["ts"])
    return all_symbol_bars


def historical_vol_ratio(bar_volume, regular_daily_volume, session_minutes=SESSION_MINUTES):
    """
    Verbatim reproduction of backtest_v10.py's `historical_vol_ratio`
    (read/confirmed 2026-09-11 while building this engine):

        def historical_vol_ratio(bar, regular_daily_volume, session_minutes=960):
            if not regular_daily_volume or regular_daily_volume <= 0 or session_minutes <= 0:
                return None
            regular_per_minute = regular_daily_volume / session_minutes
            if regular_per_minute <= 0:
                return None
            return bar.volume / regular_per_minute

    Confirmed by reading it directly: it needs ONLY the current bar's own
    volume plus the symbol's REGULAR_DAILY_VOLUME baseline and the fixed
    960-minute extended-session-length constant - there is no trailing
    window and no "elapsed minutes so far today" input, so nothing about a
    symbol's own volume HISTORY needs to be persisted across cycles for
    this function specifically (unlike v3's strategy.py, which does keep a
    trailing vol_window). Takes the bar's volume directly (a float) rather
    than a Bar object, since that's all this needs.
    """
    if not regular_daily_volume or regular_daily_volume <= 0 or session_minutes <= 0:
        return None
    regular_per_minute = regular_daily_volume / session_minutes
    if regular_per_minute <= 0:
        return None
    return bar_volume / regular_per_minute


class SymState:
    """Mutable per-symbol roster entry - mirrors backtest_v21.py/backtest_v22.py's `Sym` class."""

    def __init__(self, symbol):
        self.symbol = symbol
        self.held = False
        self.shares = 0
        self.entry_price = None
        self.peak_high = None
        self.last_price = None
        self.ever_gained = False
        self.entry_count = 0
        self.hod = None
        self.last_bar_time = None   # time_str of the last bar processed for this symbol, any cycle
        self.recent_bars = []       # trailing [{"o":..,"c":..}] window, used by v22's revival trigger
        self.bars_log = []          # capped OHLC history since current entry, for the dashboard chart
        # ADDITIVE 2026-09-15 for v24 (backtest_gap_hold_pool_tightstop.py's live port):
        # the exact level a stopped-out position must reclaim to re-buy (entry_price
        # for a stage1 cut, peak_high for a stage2 cut) and which stage produced it.
        # v21/v22 never set or read these - they use the separate `hod` mechanism
        # above for their own re-entry trigger instead - so this is a no-op addition
        # for them (always stays None, never serialized into any v21/v22 decision).
        self.watch_level = None
        self.last_stop_stage = None
        # ADDITIVE 2026-09-15 for v24: the FIXED price this holding cycle's
        # stage1/stage2 thresholds are measured against. Deliberately kept
        # separate from `entry_price` above, which the shared rebalance()
        # below keeps mutating into a weighted-average COST BASIS as top-ups
        # happen (that's the correct field for P&L, but using it for stage
        # thresholds too - an earlier version of this file did exactly that -
        # let a same-cycle rebalance top-up silently shift a position's stop
        # level, which is wrong and doesn't match the validated backtest).
        # v21/v22 never set or read this - always stays None for them.
        self.stage_entry_price = None


def sym_from_seed(symbol, seed):
    s = SymState(symbol)
    if seed is None:
        return s
    s.held = seed.get("held", False)
    s.shares = seed.get("shares", 0)
    s.entry_price = seed.get("entry_price")
    s.peak_high = seed.get("peak_high")
    s.last_price = seed.get("last_price")
    s.ever_gained = seed.get("ever_gained", False)
    s.entry_count = seed.get("entry_count", 0)
    s.hod = seed.get("hod")
    s.last_bar_time = seed.get("last_bar_time")
    s.recent_bars = list(seed.get("recent_bars", []))
    s.bars_log = list(seed.get("bars_log", []))
    s.watch_level = seed.get("watch_level")
    s.last_stop_stage = seed.get("last_stop_stage")
    s.stage_entry_price = seed.get("stage_entry_price")
    return s


def sym_to_seed(s):
    return {
        "held": s.held, "shares": s.shares, "entry_price": s.entry_price,
        "peak_high": s.peak_high, "last_price": s.last_price, "ever_gained": s.ever_gained,
        "entry_count": s.entry_count, "hod": s.hod, "last_bar_time": s.last_bar_time,
        "recent_bars": s.recent_bars, "bars_log": s.bars_log,
        "watch_level": s.watch_level, "last_stop_stage": s.last_stop_stage,
        "stage_entry_price": s.stage_entry_price,
    }


def build_events(roster, bars_by_symbol):
    """
    For every symbol present either in the persisted roster or in this
    cycle's bars-files, filter to bars strictly newer than that symbol's
    persisted last_bar_time (mirrors run_scan_cycle.py's cutoff convention),
    then merge every symbol's new bars into ONE globally chronological
    (ts, symbol) event stream - the same sort key backtest_v21.py/
    backtest_v22.py use for their single full-day event loop
    (`events.sort(key=lambda e: (e[0], e[1]))`).

    IMPORTANT for exactness across cycle boundaries: this only reproduces
    the full-day backtest's result bit-for-bit if a cycle boundary never
    splits a same-timestamp group of bars across two different symbols
    between two different cycles (that would reorder relative to the
    single-pass sort). In production this holds because every live cycle
    fetches "new bars since last cycle" for every tracked symbol at the same
    wall-clock cutoff, so all symbols' new bars share the same time range
    each cycle. validate_live_engines.py's chunked replay enforces the same
    property by cutting chunks on absolute time boundaries applied
    uniformly across all symbols, not per-symbol bar counts.

    Returns (events, ts_to_time_str, per_symbol_new_bars) where events is a
    list of (ts, symbol, Bar) tuples in the fixed processing order, and
    per_symbol_new_bars is used only to advance last_bar_time/recent_bars
    bookkeeping.
    """
    all_symbols = set(roster.keys()) | set(bars_by_symbol.keys())
    events = []
    ts_to_time_str = {}
    per_symbol_new_bars = {}

    for sym in all_symbols:
        s = roster.get(sym)
        cutoff_ts = parse_ts(s.last_bar_time) if (s and s.last_bar_time) else 0
        bars_meta = bars_by_symbol.get(sym, [])
        new_bars_meta = [b for b in bars_meta if b["ts"] > cutoff_ts]
        per_symbol_new_bars[sym] = new_bars_meta
        for bm in new_bars_meta:
            bar = Bar(ts=bm["ts"], open=bm["open"], high=bm["high"], low=bm["low"],
                      close=bm["close"], volume=bm["volume"])
            events.append((bm["ts"], sym, bar))
            ts_to_time_str[bm["ts"]] = bm["time_str"]

    events.sort(key=lambda e: (e[0], e[1]))
    return events, ts_to_time_str, per_symbol_new_bars


def update_common_bar_state(s, bar, recent_bars_cap):
    """
    The part of backtest_v21.py/backtest_v22.py's per-event preamble that is
    IDENTICAL in both engines and runs unconditionally for every bar,
    regardless of held/discovered status:

        prior_hod = s.hod
        s.last_price = bar.close
        breakout = prior_hod is not None and bar.high > prior_hod
        s.hod = bar.high if prior_hod is None else max(prior_hod, bar.high)

    Also advances the `recent_bars` trailing window (open/close only) that
    v22's revival trigger needs - this is new bookkeeping the one-shot
    backtests don't need (they can just index into the full in-memory bars
    list) but a resumable cycle engine does. Returns (prior_hod, breakout).
    """
    prior_hod = s.hod
    s.last_price = bar.close
    breakout = prior_hod is not None and bar.high > prior_hod
    s.hod = bar.high if prior_hod is None else max(prior_hod, bar.high)

    s.recent_bars.append({"o": bar.open, "c": bar.close})
    if len(s.recent_bars) > recent_bars_cap:
        s.recent_bars = s.recent_bars[-recent_bars_cap:]

    return prior_hod, breakout


def append_bars_log(s, bar, time_str):
    s.bars_log.append({"t": time_str, "o": bar.open, "h": bar.high, "l": bar.low, "c": bar.close})
    if len(s.bars_log) > MAX_BARS_LOG:
        s.bars_log = s.bars_log[-MAX_BARS_LOG:]


def make_rebalance(roster, trades, realized_pnl_box, ts_to_time_str, total_capital):
    """
    Byte-for-byte reproduction of the `rebalance()` closure inside
    run_backtest_v21()/run_backtest_v22() (verified identical between the
    two source files before factoring this out). Trims/tops-up every
    currently-held symbol to an equal split of `total_capital`, logging a
    trim_sell/topup_buy trade for each nonzero adjustment. Top-ups update
    entry_price to a weighted-average cost basis; trims realize P&L on the
    sold shares immediately.
    """
    def _log(sym, action, price, shares, reason, ts, pnl=None):
        if shares <= 0:
            return
        trades.append({
            "symbol": sym, "action": action, "price": round(price, 4),
            "shares": shares, "reason": reason, "ts": ts,
            "time_str": ts_to_time_str.get(ts),
            "pnl_dollars": round(pnl, 4) if pnl is not None else None,
        })
        if pnl is not None:
            realized_pnl_box[0] += pnl

    def rebalance(ts):
        held_syms = [s for s in roster.values() if s.held]
        n = len(held_syms)
        if n == 0:
            return
        target_alloc = total_capital / n
        for s in held_syms:
            price = s.last_price
            if price <= 0:
                continue
            target_shares = int(target_alloc // price)
            if target_shares < s.shares:
                sell_shares = s.shares - target_shares
                pnl = (price - s.entry_price) * sell_shares
                _log(s.symbol, "trim_sell", price, sell_shares, "rebalance_trim", ts, pnl)
                s.shares = target_shares
                if s.shares == 0:
                    s.held = False
            elif target_shares > s.shares:
                add_shares = target_shares - s.shares
                if add_shares > 0:
                    old_cost = s.shares * s.entry_price
                    new_cost = add_shares * price
                    s.entry_price = (old_cost + new_cost) / (s.shares + add_shares)
                    s.shares += add_shares
                    _log(s.symbol, "topup_buy", price, add_shares, "rebalance_topup", ts)

    return rebalance, _log


def build_trades_doc(date, strategy_version, all_trades, roster, total_capital, realized_pnl_running):
    """
    Summary shape mirrors run_scan_cycle.py's trades_doc summary
    (closed_count/wins/losses/win_rate_pct/realized_pnl_dollars/open_count/
    unrealized_pnl_dollars), adapted for multi-position v21/v22:
      - closed_count/wins/losses/win_rate_pct are computed from "full_sell"
        actions ONLY, matching run_v22_4days.py's summarize() (trim_sell/
        topup_buy are rebalance mechanics, not a trade's win/loss verdict).
      - realized_pnl_dollars is `round(realized_pnl_running, 2)`, where
        realized_pnl_running is the RAW (unrounded) running accumulator
        threaded across cycles via sim_state - this matches exactly what
        run_backtest_v21()/run_backtest_v22() return as `realized_pnl`
        (their `log()` closure adds every non-None pnl, BEFORE rounding, to
        a running total). Deliberately NOT recomputed by summing the
        per-trade rounded `pnl_dollars` values stored in `all_trades` -
        summing already-4-decimal-rounded numbers can drift by a
        fraction of a cent from the true unrounded total as more trades
        accumulate across many cycles, which would violate the "exact to
        the cent" validation requirement.
    """
    full_sells = [t for t in all_trades if t["action"] == "full_sell"]
    wins = [t for t in full_sells if t["pnl_dollars"] > 0]
    losses = [t for t in full_sells if t["pnl_dollars"] <= 0]
    realized_pnl_dollars = round(realized_pnl_running, 2)

    open_positions = []
    for s in roster.values():
        if not s.held:
            continue
        unreal = (s.last_price - s.entry_price) * s.shares
        open_positions.append({
            "symbol": s.symbol, "status": "open", "shares": s.shares,
            "entry_price": s.entry_price, "peak_high": s.peak_high, "last_price": s.last_price,
            "ever_gained": s.ever_gained, "entry_count": s.entry_count,
            "unrealized_pnl_dollars": round(unreal, 4),
            "unrealized_ret_pct": round((s.last_price - s.entry_price) / s.entry_price * 100, 4) if s.entry_price else None,
            "as_of_time": s.bars_log[-1]["t"] if s.bars_log else None,
            "bars": s.bars_log[-MAX_BARS_LOG:],
        })
    unrealized_pnl_dollars = round(sum(p["unrealized_pnl_dollars"] for p in open_positions), 2)

    trades_doc = {
        "date": date,
        "strategy_version": strategy_version,
        "assumed_total_capital": total_capital,
        "trades": all_trades,
        "summary": {
            "closed_count": len(full_sells),
            "wins": len(wins),
            "losses": len(losses),
            "win_rate_pct": round(len(wins) / len(full_sells) * 100, 2) if full_sells else None,
            "realized_pnl_dollars": realized_pnl_dollars,
            "open_count": len(open_positions),
            "unrealized_pnl_dollars": unrealized_pnl_dollars,
        },
    }
    return trades_doc, open_positions


# ---------------------------------------------------------------------------
# ADDITIVE 2026-09-14: compounding capital pool + account-level drawdown halt
# for the v21/v22 LIVE forward-test loops, requested by the user.
#
# Background (see /areas/day-trading-system.md for the full history): on
# 2026-09-11 the user requested TRUE cross-day compounding for v21/v22 (each
# day's pool = the prior day's ending balance, floored at $0 as a defensive
# guard against a negative pool) - this was built and backtest-validated as
# backtest_v21_compound.py/backtest_v21_crossday.py etc., but a LIVE version
# was never built, so the live loops that actually started Monday 2026-09-14
# ran the ORIGINAL flat-$5,000 engines instead. This section closes that gap
# by porting the already-validated compounding-with-floor design into the
# live sim_state flow, plus a NEW account-level 10%-drawdown halt (modeled
# on risk_guard.py's real-money circuit breaker: permanent halt on new
# entries only, until an explicit manual reset - never an automatic
# next-day/timer reset) that the user separately asked for so this guardrail
# can be validated in the paper loops before it ever matters for real money.
#
# Nothing below changes stage1/stage2/entry-trigger DECISION math for v21 or
# v22, and run_scan_cycle.py (v3) is untouched entirely. The only things
# these functions touch are (a) what total_capital value gets fed into the
# EXISTING make_rebalance()/build_trades_doc() calls, computed once per
# cycle exactly like the original flat value was, and (b) whether the
# EXISTING entry-trigger blocks in v21_run_scan_cycle.py/v22_run_scan_cycle.py
# are allowed to fire at all this cycle. When a caller passes none of
# capital_mode/halt_drawdown_pct/risk_reset, and no risk_halt/
# total_capital_mode was ever persisted in sim_state, every function here is
# either not called or returns exactly the old behavior - see
# validate_live_engines.py, re-run after this change to confirm.
# ---------------------------------------------------------------------------

def compute_equity(roster, realized_pnl_running, base_notional=TOTAL_CAPITAL):
    """
    Mark-to-market account equity = base_notional ($5,000, the original
    forward-test notional) + realized_pnl_running (this sim_state's own
    continuously-threaded cumulative realized P&L accumulator) + unrealized
    P&L on whatever is currently held. Floored at 0.0 (a pool can't go
    negative - matches the "floored at $0 as a defensive guard" design
    already approved/backtested for v21_compound/v22_compound on 2026-09-11).
    """
    unrealized = 0.0
    for s in roster.values():
        if s.held and s.entry_price is not None and s.last_price is not None:
            unrealized += (s.last_price - s.entry_price) * s.shares
    return max(0.0, base_notional + realized_pnl_running + unrealized)


def init_or_reset_risk_halt(sim_state, roster, realized_pnl_running, halt_drawdown_pct,
                             risk_reset, base_notional=TOTAL_CAPITAL):
    """
    Called ONCE at the very start of a cycle, BEFORE processing this cycle's
    bar events. Returns the risk_halt dict to use for gating THIS cycle's
    entries (or None if the halt feature has never been turned on for this
    sim_state and isn't being turned on now - the exact pre-2026-09-14
    behavior).

    - If risk_reset=True: clears any existing halt and re-seeds
      starting_principal from CURRENT equity (a deliberate, explicit manual
      action - "go back and restart it manually", never automatic).
    - Else if no risk_halt has ever been persisted and halt_drawdown_pct is
      given: initializes it now, seeding starting_principal from CURRENT
      equity - this is the "cutover" point; every cycle recorded before this
      one is left exactly as already written, nothing retroactive.
    - Else if no risk_halt persisted and halt_drawdown_pct is None: returns
      None (feature untouched, original behavior).
    - Else: an existing risk_halt is carried forward as-is (a halt already
      in effect stays in effect; the drawdown re-check for a NOT-yet-halted
      tracked account happens separately, at the END of a cycle, in
      recheck_risk_halt - not here).
    """
    existing = sim_state.get("risk_halt")

    if risk_reset or existing is None:
        if not risk_reset and halt_drawdown_pct is None:
            return None
        if halt_drawdown_pct is None:
            raise ValueError("--risk-reset requires --halt-drawdown-pct to also be given")
        baseline = compute_equity(roster, realized_pnl_running, base_notional)
        insolvent = baseline <= 0
        now_iso = datetime.now(timezone.utc).isoformat() if insolvent else None
        return {
            "halted": insolvent,
            "halt_reason": (
                f"starting principal at or below zero (${baseline:.2f}) - insolvent, "
                f"no capital to allocate" if insolvent else None
            ),
            "halt_time_iso": now_iso,
            "halt_equity_at_trigger": baseline if insolvent else None,
            "starting_principal": baseline,
            "halt_drawdown_pct": halt_drawdown_pct,
        }

    return dict(existing)


def recheck_risk_halt(risk_halt, roster, realized_pnl_running, base_notional=TOTAL_CAPITAL):
    """
    Called AFTER a cycle's bar events (and this cycle's own exits/entries)
    have been processed. No-op if risk_halt is None or already halted.
    Otherwise re-evaluates current equity against the fixed
    starting_principal baseline and flips halted=True the moment the
    drawdown_pct threshold is breached - this is what makes the halt
    "permanent until a human manually resets it" rather than something that
    could flicker on/off cycle to cycle.
    """
    if risk_halt is None or risk_halt["halted"]:
        return risk_halt
    pct = risk_halt["halt_drawdown_pct"]
    equity = compute_equity(roster, realized_pnl_running, base_notional)
    threshold = risk_halt["starting_principal"] * (1 - pct / 100.0)
    if equity <= threshold:
        risk_halt = dict(risk_halt)
        risk_halt["halted"] = True
        risk_halt["halt_reason"] = (
            f"equity ${equity:.2f} breached {pct:.1f}% drawdown threshold "
            f"(starting principal ${risk_halt['starting_principal']:.2f}, "
            f"halt level ${threshold:.2f})"
        )
        risk_halt["halt_time_iso"] = datetime.now(timezone.utc).isoformat()
        risk_halt["halt_equity_at_trigger"] = equity
    return risk_halt


def flatten_all_positions(roster, new_trades, realized_pnl_box, reason="risk_halt_flatten"):
    """
    ADDITIVE 2026-09-14 (later same day, user request): "when we lose 10% of
    the principal... the system should completely flatten and shut off until
    we started again manually." The halt as originally built only blocked
    NEW entries - an already-open position could keep riding its own normal
    exit logic instead of being closed out immediately. This forces every
    currently-held roster position closed at its last known price the moment
    the account is halted, self-healing every cycle (safe/no-op once nothing
    is held) rather than firing only on the exact cycle the halt triggers -
    so it also correctly cleans up a position that was already open BEFORE
    this feature existed (e.g. v22's MTNB, open when this was added).
    Appends one "full_sell" trade per closed position directly (same shape
    make_rebalance's `log` closure produces) and returns the list of symbols
    closed, so callers can report it as a genuinely eventful action.
    """
    closed_symbols = []
    for s in roster.values():
        if not s.held or s.shares <= 0:
            continue
        price = s.last_price
        pnl = (price - s.entry_price) * s.shares if price is not None and s.entry_price is not None else 0.0
        new_trades.append({
            "symbol": s.symbol, "action": "full_sell", "price": round(price, 4) if price is not None else None,
            "shares": s.shares, "reason": reason, "ts": None,
            "time_str": s.last_bar_time,
            "pnl_dollars": round(pnl, 4),
        })
        realized_pnl_box[0] += pnl
        s.shares = 0
        s.held = False
        closed_symbols.append(s.symbol)
    return closed_symbols
